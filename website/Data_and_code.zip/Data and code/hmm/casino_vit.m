 % Viterbi algorithm for the occasionaly dishonest casino example
%
% Requires Kevin Murphy's toolboxes (HMM, KPMtools, and KPMstats)
% on your path, executing startup.m should take care of this.
% PM20220930

% 2 states, 6 symbols

close all;
clear all;
clc;
echo on;

Q = 2;
O = 6;

prior    = [0.5 0.5];
% state 1: fair die / state 2: loaded die
transmat = [0.95 0.05;0.1 0.9];
obsmat   = [1/6 1/6 1/6 1/6 1/6 1/6;1/10 1/10 1/10 1/10 1/10 1/2];

% This is the example from the lecture [3 1 4 6 6 6], change this if you 
% want to see what happens for other sequences
B = multinomial_prob([3 1 4 6 6 6], obsmat);
[a,b,g,loglik] = fwdback(prior, transmat, B,'fwd_only',1);

[path,loglik] = viterbi_path(prior, transmat, B);
path
loglik
% and indeed path = [2 2 2 2 2 2] and loglik =
% log((1/10)^3*(1/2)^3*(0.9)^5*0.5) = log(0.000037)
pause; % press a key to continue 

% sample 300 rolls of a die from the model and find the optimal state 
% sequence (Viterbi)
[data,hidden] = dhmm_sample(prior, transmat, obsmat, 1, 300);  

B = multinomial_prob(data, obsmat);
[path,loglik] = viterbi_path(prior, transmat, B);

subplot(2,1,1);plot(hidden,'b');
title('Occasionally dishonest casino')
axis([-1 301 0 3])
xlabel('Roll');
yticklabels({'','Fair','Loaded',''})

subplot(2,1,2);plot(path,'r');
title('State sequence estimated using the Viterbi algorithm')
axis([-1 301 0 3]);
xlabel('Roll');
yticklabels({'','Fair','Loaded',''})

pause; % press a key to continue 

% estimate the parameters of a model from 30000 rolls of a die

data = dhmm_sample(prior, transmat, obsmat, 1, 30000);  

% initialization
prior1    = normalise(rand(Q,1)); 
transmat1 = mk_stochastic(rand(Q,Q));
obsmat1   = mk_stochastic(rand(Q,O));

% Baum-Welch (EM)
[LL, prior2, transmat2, obsmat2] = dhmm_em(data, prior1, transmat1, obsmat1, 'max_iter', 20,'thresh',1e-5);

% estimated transition probability matrix
transmat2
% estimated emission probabilities 
obsmat2
echo off;