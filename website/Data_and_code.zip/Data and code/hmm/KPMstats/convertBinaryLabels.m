% labels01 = (labelsPM+1)/2; % maps -1->0, +1->1

