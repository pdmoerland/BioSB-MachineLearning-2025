%% TEST 1
data = rand(10,5);
a = dataset(data);
labs = genlab([4 2 4],char('apple','pear','banana'));
a = dataset(a,labs);
% Ex.1.1
a = seldat(a, 2);
getlablist(a)
% Should give ‘banana’ as answer
%% TEST 2
load vanberlo.mat
load hulsman.mat
 
wk = proxm(a,'homogeneous');
Ka = a*wk;
Kb = b*wk;
w = svc_kernel(Ka,1);
 
wk = pairwise_km(a,Kp{1},'n'); 
Kpwa = a*wk;
Kpwb = b*wk;
w = svc_kernel(Kpwa);
 
Kca = combine_kernels({Ka,Kpwa},[0.5 0.5]);
Kcb = combine_kernels({Kb,Kpwb},[0.5 0.5]);
w = svc_kernel(Kca);
 
figure(1);
roc_curve = roc(Kca,w);
plot(roc_curve.xvalues, roc_curve.error);
xlabel(roc_curve.xlabel);
ylabel(roc_curve.ylabel);
% Should plot a ROC curve
%% An issue that might need particular attention is that exercise 5.1 (neural networks) seems to depend on an old version of the Neural Network toolbox
%Ex 5.1:
%Undefined function 'newff' for input arguments of type 'cell'.

%Error in ffnc (line 173)
%net = newff(ones(numunits(1),1)*[0 1],numunits(2:end),...

%Ex 5.2:
%Undefined function 'newrb' for input arguments of type 'double'.

%Error in rbnc (line 97)
%net     = newrb(+(a*ws)'+r',target,0,sigma,units,inf);

%Error in main_5_2 (line 11)
%w = rbnc(a, 50);

%Ex 5.3:
%Undefined function 'corr' for input arguments of type 'double'.

%Error in main_5_3 (line 11)
%    f_score(i) = abs(corr(labels, +a(:,i)));