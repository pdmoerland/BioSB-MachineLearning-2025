clc;
clear;
close all

%% 1.23(a)
load golub
a = a(:,[1413 738]);
b = b(:,[1413 738]);
scatterd(a);
scatterd(b);

%% 1.23(b)
%% function for 1.23(b): see extractClass.m
%function [data] = extractClass(data,class)
% lab = getlab(data);
% I = find(lab==class);
% data = +data(I,:);
%end
%% remember to set the path to be able to find user-defined functions
addpath('./')
a1 = extractClass(a,1);
a2 = extractClass(a,2);
%% Note that you could also have used a1=seldat(a,1) and a2=seldat(a,2) right away 

%% 1.23(c) (PM): option 'legend' does not work with some versions of Matlab
w1=gaussm(dataset(a1)); 
w2=gaussm(dataset(a2)); 
scatterd(a,'legend');
plotm(w1,2);
plotm(w2,2);

%% 1.23(d)
phat1 = +(b*w1); 
phat2 = +(b*w2);
[getlab(b) +phat1 +phat2]

%% 1.23(e) You can also use getprior(a)
size(a1,1)/size(a,1)
size(a2,1)/size(a,1)

%% 1.23(f)
P = [(27/38)*phat1 (11/38)*phat2]; 
[dummy, lab2] = max(P,[],2);

%% 1.25
sum(getlab(b) ~= lab2)
