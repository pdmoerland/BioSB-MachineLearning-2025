clc;
clear;
close all

%% 1.14a
a = gauss(1000, zeros(1,2), [1 0;0 4]);
scatterd(a);

%% 1.14b
figure()
a = gauss(1000, zeros(1,2), [1 1;1 4]);
scatterd(a);

%% 1.14c
% The covariance matrix should be symmetric and here it isn't it.
% However, the code still works since PRTools only looks at the
% upper triangle of the covariance matrix.
a = gauss(1000, zeros(1,2), [1 1;0 4]);
figure();
scatterd(a);
% So this effectively corresponds to the covariance matrix used in 1.14b.
figure();
b = gauss(1000, zeros(1,2), [1 1;1 4]);
scatterd(b);

%% 1.14d
figure()
a = gauss(1000, zeros(1,2), [1 1;1 1000]);
scatterd(a);
axis equal