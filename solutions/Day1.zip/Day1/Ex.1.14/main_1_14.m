clc;
clear;
close all

%% 1.14a
a = gauss(1000, zeros(1,2), [1 0;0 4]);
scatterd(a);

%% 1.14b
figure()
a = gauss(1000, zeros(1,2), [1 1;1 4]);
scatterd(a);

%% 1.14c
figure()
a = gauss(1000, zeros(1,2), [1 0;0 1000]);
scatterd(a);
axis equal