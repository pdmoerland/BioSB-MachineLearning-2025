clc;
clear;
close all

a = gendats([20 20],1,8);

k = 1;
w = knnm(a,k);

scatterd(a); 
plotm(w,1);

%% 1.21b
gridsize(500);
scatterd(a); 
plotm(w,1);


%% 1.21c
for k=[1 5 15]
    figure();
    w = knnm(a,k);
    scatterd(a); 
    plotm(w,1);
end




