%% Code for the exercises of the BioSB course on Machine Learning
%% January 2025- Perry D Moerland

%% Day 2

%% 2.1(a)
a = gendats([50 50],2,1);
scatterd(a);

%% 2.1(b)
w = loglc(a);
plotm(w);
%% What does the next plot actually show? Looks like a bug??
%plotm(w,3);
testc(a*w);

%% 2.1(c)
a = gendats([50 50],2,5)
scatterd(a);
w = loglc(a);
plotm(w);
testc(a*w);

%% 2.3(a)
a = gendatb([20 20]);
scatterd(a);

%% 2.3(b)
w1 = qdc(a);
w2 = parzenc(a);
w3 = knnc(a);
w  = {w1,w2,w3};

% Throws an error related to 'legend' with some versions of Matlab
%plotc(w);
plotc(w1);
plotc(w2,'red');
plotc(w3,'blue');
testc(a*w);

%% 2.5(a)
w = qdc(a);
testc({a,b}*w);

%% 2.5(b)
crossval(a,qdc,10,1);
crossval(a,qdc,20,1);

%% 2.5(c) throws an error with some versions of Matlab when not specifying 'nolegend'
plote(roc(a,w),'nolegend');
plote(roc(b,w),'nolegend');

%% 2.6(a)
figure();
a = gendats([10 10],2,2);
scatterd(a);
figure();
b = gendats([1000 1000],2,2);
scatterd(b);

%% 2.6(b)
w1 = knnc(a,1);
testc({a,b}*w1);

%% 2.6(c)
a = gendats([10 10],5,2);
b = gendats([1000 1000],5,2);

%% 2.6(d)
w1 = knnc(a,1);
testc({a,b}*w1);

%% 2.6(e)
err = [];
dims = [2 3 5 10 25 100];
nrepeats = 25;
for i=dims 
  total = 0;
  for j=1:nrepeats
    a =  gendats([10 10],i,2);
    b = gendats([1000 1000],i,2);
    w1 = knnc(a,1);
    total = total + +testc(b*w1);
  end
  err= [err total/nrepeats];
end
plot(dims,err);

%% 2.10(a)
load cigars;
scatterd(a)

wq = qdc(a);
wl = ldc(a);
% Throws an error related to 'legend' with some versions of Matlab
%plotc({wq,wl});
plotc(wq);
plotc(wl,'red');

%% 2.10(b)
testc(a*{wq,wl});

%% 2.11
a = gendatb([100 100]);
scatterd(a);

wq = qdc(a);
wl = ldc(a);
% Throws an error related to 'legend' with some versions of Matlab
%plotc({wq,wl});
plotc(wq);
plotc(wl,'red');
testc(a*{wq,wl});

%% 2.12(a)
load golub
a = a(:,[1413 738]);
b = b(:,[1413 738]);

%% 2.12(b)
w = treec(a);
testc({a,b}*w);

%% 2.12(c)
scatterd(a);
plotc(w);

%% 2.12(d)
for i=0:5
  %w= treec(a,'infcrit',i);
  w= treec(a,'maxcrit',i);
  %w= treec(a,'fishcrit',i);  
  testc(b*w);
end

plotc(w)

%% 2.12(e)
load golub;
for i=0:5
  %w= treec(a,'infcrit',i);
  %w= treec(a,'maxcrit',i);
  w= treec(a,'fishcrit',i);   
  testc(a*w);
  testc(b*w);
end

%% 2.13(a)
train = gendatb([10 10]);

w1 = nmc(train);
w2 = ldc(train); 
w3 = qdc(train);
w4 = fisherc(train);
w5 = parzenc(train);
w6 = knnc(train,1);
w7 = treec(train);
W = {w1,w2,w3,w4,w5,w6,w7};
testc(train*W);

scatterd(train); 
% Throws an error related to 'legend' with some versions of Matlab
%plotc(W);
plotc(w1);
plotc(w2,'red');
plotc(w3,'blue');
plotc(w4,'green');
plotc(w5,'yellow');
plotc(w6,'magenta');
plotc(w7,'cyan');

%% 2.13(b)
newtrain = train;
newtrain(:,2) = 10*newtrain(:,2);

w1 = nmc(newtrain);
w2 = ldc(newtrain); 
w3 = qdc(newtrain);
w4 = fisherc(newtrain);
w5 = parzenc(newtrain);
w6 = knnc(newtrain,1);
w7 = treec(newtrain);
W = {w1,w2,w3,w4,w5,w6,w7};
testc(newtrain*W);

scatterd(newtrain); 
% Throws an error related to 'legend' with some versions of Matlab
%plotc(W);
plotc(w1);
plotc(w2,'red');
plotc(w3,'blue');
plotc(w4,'green');
plotc(w5,'yellow');
plotc(w6,'magenta');
plotc(w7,'cyan');

%% 2.14(a)
load hall;
scatterd(a);

%% 2.15(a,b)
load rnd;
scatterd(a);
interactclust(a,'c');
%% 2.15(c)
interactclust(a,'s');
interactclust(a,'a');

%% 2.16
load hall;
scatterd(a);
interactclust(a,'c');

%% 2.17(a)
interactclust(a,'s');
%% 2.17(b)
interactclust(a,'a');

%% 2.18(a)
load cigars;
scatterd(a);
%% 2.18(b)
interactclust(a,'s');
%% 2.18(c)
interactclust(a,'c');

%% 2.19(a)
load messy;
scatterd(a);
interactclust(a,'c');
%% 2.19(b) 
interactclust(a,'s');

%% 2.20(b)
load cigars;
kmclust(a,2,1,1);

load messy;
kmclust(a,2,1,1);

%% 2.21(a)
load triclust;
scatterd(a);

%% 2.21(b)
kmclust(a,3,1,1);

%% 2.23(a)
load triclust;
interactclust(a,'s',1);

%% 2.23(b)
interactclust(a,'c',1);

%% 2.24(a)
load hall;
interactclust(a,'s',1);

%% 2.25(a)
load messy;
interactclust(a,'s',1);

%% 2.25 (c)
interactclust(a,'c',1);

%% 2.26(a)
a = +gendats([50,50],2,10);
scatterd(a);

%% 2.26(b): ignore possible warnings
g = [1 2 3 5 10 20 40 50 100];
nreps = 10;
for i=1:length(g)
  for j=1:nreps
  [p,labs,ws(i,j)] = kmclust(a,g(i),0,0);
  end
end

WS_mean = mean(ws,2);
WS_std  = std(ws,0,2);
errorbar(g,WS_mean/WS_mean(1),WS_std/WS_mean(1));

% Actually this is the correct way to normalize but on this dataset the differences are negligible
ws = ws ./ ws(1);
WS_mean = mean(ws,2);
WS_std  = std(ws,0,2);
hold on;
errorbar(g,WS_mean,WS_std,'red');

%% 2.26(d)
a = +gendats([50,50],2,5);
%% and now run the code of 2.26(b)

%% 2.27
a = gendats([50 50],2,0);
%% and now run the code of 2.26(b)

%% 2.28(b)
load triclust;
scatterd(a)

%% 2.28(c)
hdb(a,'c','e',10);

%% 2.28(d)
load hall;
hdb(a,'c','e',20);

%% 2.28(e)
load cigars;
hdb(a,'c','e',20);

%% 2.29(a)
load triclust;
em(a,3,'circular',0,1,0);

%% 2.29(b)
load cigars;
em(a,1,'gauss',0,1,0);
em(a,2,'gauss',0,1,0);
em(a,5,'gauss',0,1,0);

%% 2.29(c)
ncomp = [1:5]
nreps = 20;
for i=ncomp
  for j=1:nreps
  lik(j) = em(a,i,'gauss',0,0,0);
  end
  L_mean(i) = mean(lik);
  L_std(i)  = std(lik);
end
errorbar(ncomp,L_mean,L_std);

%% 2.29(d)
load rnd;
scatterd(a);
%% and now run the code of 2.29(c)

%% 2.29(e)
load messy;
scatterd(a);

ncomp = [1:5];
nreps = 20;
for i=ncomp
  for j=1:nreps
  lik(j) = em(a,i,'circular',0,0,0);
  end
  L_mean(i) = mean(lik);
  L_std(i)  = std(lik);
end
errorbar(ncomp,L_mean,L_std);