clc;
clear
load vanberlo.mat
load hulsman.mat

feat_std = std(a);
bar(feat_std);