clc;
clear

load vanberlo.mat
load hulsman.mat

wk = proxm(a,'homogeneous');
Ka = a*wk;
Kb = b*wk;
w = svc_kernel(Ka,1);
roc_curve = roc(Ka,w);
plot(roc_curve.xvalues, roc_curve.error);
xlabel(roc_curve.xlabel);
ylabel(roc_curve.ylabel);
% legend({roc_curve.names});
