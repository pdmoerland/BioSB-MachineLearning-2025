clc;
clear;

prprogress on; 
w = []; 
rand('state',99);
randn('state',99);
a = gendatb(100);

w = rbnc(a, 10);
figure(1); 
clf; 
scatterd(a); 
plotc(w); 
drawnow;