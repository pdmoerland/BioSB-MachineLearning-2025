clear all;
load iris;
w = fisherm(a);
scatterd(a*w);